const { Pool } = require('pg');

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'account',
  password: '123456789',
  port: 5432 // or your database port
});

module.exports = {pool};
