const pool = require('../db');

// Create a destination for an account
async function createDestination(req, res) {
  try {
    const { accountId, url, method, headers } = req.body;
    const destinationId = uuidv4();

    const query = 'INSERT INTO destinations(destination_id, account_id, url, method, headers) VALUES($1, $2, $3, $4, $5) RETURNING *';
    const values = [destinationId, accountId, url, method, JSON.stringify(headers)];

    const result = await pool.query(query, values);

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error creating destination:', error);
    res.status(500).json({ error: 'Failed to create destination' });
  }
}

// Get destinations for an account
async function getDestinations(req, res) {
  try {
    const { accountId } = req.params;

    const query = 'SELECT * FROM destinations WHERE account_id = $1';
    const values = [accountId];

    const result = await pool.query(query, values);

    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching destinations:', error);
    res.status(500).json({ error: 'Failed to fetch destinations' });
  }
}
// Destination service methods
async function getDestinationsByAccountId(accountId) {
  const query = 'SELECT * FROM destinations WHERE account_id = $1';
  const values = [accountId];
  const result = await pool.query(query, values);
  return result.rows;
}

async function updateDestination(accountId, destinationId, destinationData) {
  const { url, method, headers } = destinationData;
  const query = 'UPDATE destinations SET url = $1, method = $2, headers = $3 WHERE account_id = $4 AND destination_id = $5 RETURNING *';
  const values = [url, method, headers, accountId, destinationId];
  const result = await pool.query(query, values);
  return result.rows[0];
}

async function deleteDestination(accountId, destinationId) {
  const query = 'DELETE FROM destinations WHERE account_id = $1 AND destination_id = $2';
  const values = [accountId, destinationId];
  await pool.query(query, values);
}

module.exports = {
  createDestination,
  getDestinations,
  getDestinationsByAccountId,
  updateDestination,
  deleteDestination,
};
