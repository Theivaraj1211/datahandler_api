const pool = require('../db');

// Handle incoming data
async function handleIncomingData(req, res) {
  try {
    const { headers, body } = req;
    const secretToken = headers['cl-x-token'];

    if (!secretToken) {
      res.status(401).json({ error: 'Unauthenticated' });
      return;
    }

    const destinationHeaders = { ...headers, 'Content-Type': 'application/json' };
    const destinationMethod = 'POST';

    const query = 'SELECT * FROM accounts WHERE app_secret_token = $1';
    const values = [secretToken];
    const accountResult = await pool.query(query, values);

    if (accountResult.rows.length === 0) {
      res.status(401).json({ error: 'Unauthenticated' });
      return;
    }

    const account = accountResult.rows[0];
    const accountId = account.account_id;

    const destinationsQuery = 'SELECT * FROM destinations WHERE account_id = $1';
    const destinationsValues = [accountId];
    const destinationsResult = await pool.query(destinationsQuery, destinationsValues);
    const destinations = destinationsResult.rows;

    if (destinations.length === 0) {
      res.status(400).json({ error: 'No destinations found for the account' });
      return;
    }

    destinations.forEach(destination => {
      const { url, method } = destination;
      let dataToSend;

      if (method === 'GET') {
        const queryParams = new URLSearchParams(body);
        const destinationURL = `${url}?${queryParams}`;
        dataToSend = destinationURL;
      } else {
        dataToSend = body;
      }

      // Use your preferred HTTP client to send data
      sendData(url, method, destinationHeaders, dataToSend);
    });

    res.json({ message: 'Data sent to destinations' });
  } catch (error) {
    console.error('Error handling incoming data:', error);
    res.status(500).json({ error: 'Failed to handle incoming data' });
  }
}

// Helper function to send data to a destination URL
function sendData(url, method, headers, data) {
  // Use your preferred HTTP client to send data to the specified destination
  console.log(`Sending data to ${method} ${url}`);
  console.log('Headers:', headers);
  console.log('Data:', data);
}

module.exports = {
  handleIncomingData
};
