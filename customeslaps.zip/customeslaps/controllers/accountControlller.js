const pool = require('../db');

// Create an account
async function createAccount(req, res) {
  try {
    const { email, accountName, website } = req.body;
    const accountId = uuidv4();
    const appSecretToken = uuidv4();

    const query = 'INSERT INTO accounts(account_id, email, account_name, app_secret_token, website) VALUES($1, $2, $3, $4, $5) RETURNING *';
    const values = [accountId, email, accountName, appSecretToken, website];

    const result = await pool.query(query, values);

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error creating account:', error);
    res.status(500).json({ error: 'Failed to create account' });
  }
}

// Get all accounts
async function getAccounts(req, res) {
  try {
    const query = 'SELECT * FROM accounts';
    const result = await pool.query(query);

    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching accounts:', error);
    res.status(500).json({ error: 'Failed to fetch accounts' });
  }
}

async function updateAccount(accountId, accountData) {
  const { email, accountName, appSecretToken, website } = accountData;
  const query = 'UPDATE accounts SET email = $1, account_name = $2, app_secret_token = $3, website = $4 WHERE account_id = $5 RETURNING *';
  const values = [email, accountName, appSecretToken, website, accountId];
  const result = await pool.query(query, values);
  return result.rows[0];
}
async function getAccountById(accountId) {
  const query = 'SELECT * FROM accounts WHERE account_id = $1';
  const values = [accountId];
  const result = await pool.query(query, values);
  return result.rows[0];
}
async function deleteAccount(accountId) {
  const query = 'DELETE FROM accounts WHERE account_id = $1';
  const values = [accountId];
  await pool.query(query, values);
}
module.exports = {
  createAccount,
  getAccounts,
  updateAccount,
  getAccountById,
  deleteAccount,
};
