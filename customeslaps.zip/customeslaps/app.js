const express = require('express');
const accountController = require('./controllers/accountControlller');
const destinationController = require('./controllers/destinationController');
const dataHandlerController = require('./controllers/dataHandlerController');

const app = express();
app.use(express.json());

// Account routes
app.get('/accounts', accountController.getAccounts);
app.get('/accounts/:accountId', accountController.getAccountById);
app.post('/accounts', accountController.createAccount);
app.put('/accounts/:accountId', accountController.updateAccount);
app.delete('/accounts/:accountId', accountController.deleteAccount);

// Destination routes
app.get('/accounts/:accountId/destinations', destinationController.getDestinationsByAccountId);
app.post('/accounts/:accountId/destinations', destinationController.createDestination);
app.put('/accounts/:accountId/destinations/:destinationId', destinationController.updateDestination);
app.delete('/accounts/:accountId/destinations/:destinationId', destinationController.deleteDestination);

// Data handler route
app.post('/server/incoming_data', dataHandlerController.handleIncomingData);

const port = 3000;
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
